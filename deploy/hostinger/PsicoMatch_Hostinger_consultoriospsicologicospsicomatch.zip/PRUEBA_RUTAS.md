# Prueba de rutas — dominio real

Base: `https://consultoriospsicologicospsicomatch.com`

## Públicas

| Ruta | Esperado |
|------|----------|
| `/` | Portada PsicoMatch (listado de publicados) |
| `/login` | Formulario de acceso |
| `/registro` | Registro de paciente |
| `/forgot-password` | Recuperación |
| `/activar-cuenta` | Formulario (sin token: error controlado) |
| `/consultorios/CON001` | Página del consultorio demo (si está publicado) |
| `/consultorios/CON001/especialistas/PSI001` | Perfil público del especialista demo |
| `/assets/css/style.css` | CSS 200 |
| Ruta inexistente | 404 |

## Protegidas (requieren sesión)

| Ruta | Rol |
|------|-----|
| `/administrador` | ADMINISTRADOR |
| `/consultorio` | CONSULTORIO |
| `/psicologo` | PSICOLOGO |
| `/paciente` | PACIENTE |

## Redirecciones

| Origen | Destino |
|--------|---------|
| `http://consultoriospsicologicospsicomatch.com/...` | HTTPS apex |
| `https://www.consultoriospsicologicospsicomatch.com/...` | HTTPS apex |

## Validación local de URLs (sin DNS)

```bash
php deploy/hostinger/scripts/validar_urls_produccion.php
```

Simula `APP_URL=https://consultoriospsicologicospsicomatch.com` y comprueba
que no se generen `localhost`, `/public` ni dobles barras.
