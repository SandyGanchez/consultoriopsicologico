<?php

use App\Helpers\Helper;

$nombrePagina = $titulo ?? 'Panel del psicólogo';

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <title>
        <?= htmlspecialchars($nombrePagina); ?>
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com">

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <link
        rel="stylesheet"
        href="<?= Helper::baseUrl('assets/css/style.css'); ?>">

    <link
        rel="stylesheet"
        href="<?= Helper::baseUrl('assets/css/psicologo.css'); ?>">

    <?php if (!empty($cargarServiciosPsicologoCss)): ?>

        <link
            rel="stylesheet"
            href="<?= Helper::baseUrl(
                'assets/css/psicologo-servicios.css'
            ); ?>"
        >

    <?php endif; ?>
</head>

<body>